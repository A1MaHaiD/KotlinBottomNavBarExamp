package com.example.bottomnavigationexamplekotlin

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.bottomnavigationexamplekotlin.fragments.FavoriteFragment
import com.example.bottomnavigationexamplekotlin.fragments.HomeFragment
import com.example.bottomnavigationexamplekotlin.fragments.SettingsFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val homeFragment = HomeFragment()
        val favoriteFragment = FavoriteFragment()
        val settingsFragment = SettingsFragment()

        makeCurrentFragment(homeFragment)
        main_fragLayout.setOnNavigationItemSelecterListener



    }

    private fun makeCurrentFragment(homeFragment: HomeFragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.main_fragLayout, homeFragment)
            commit()
        }
    }
}